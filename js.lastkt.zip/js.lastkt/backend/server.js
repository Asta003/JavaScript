require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use('/photo', express.static(path.join(__dirname, '../frontend/photo')));

// Подключение к PostgreSQL
const pool = new Pool({
    host: '5.129.248.204',
    port: 5432,
    database: 'db_levina_anastasia',
    user: 'levina_anastasia',
    password: 'Lev2025!08' 
});

// Проверка подключения
pool.connect((err, client, release) => {
    if (err) {
        console.error('❌ Ошибка подключения к PostgreSQL:', err.message);
    } else {
        console.log('✅ Подключено к PostgreSQL');
        release();
        createTables();
    }
});

// Создание таблиц
async function createTables() {
    try {
        // Таблица users
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('✅ Таблица users готова');

        // Таблица products
        await pool.query(`
            CREATE TABLE IF NOT EXISTS products (
                id SERIAL PRIMARY KEY,
                name TEXT NOT NULL,
                category TEXT DEFAULT 'figurine',
                price NUMERIC NOT NULL,
                description TEXT,
                image_url TEXT,
                stock INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('✅ Таблица products готова');

        // Таблица cart
        await pool.query(`
            CREATE TABLE IF NOT EXISTS cart (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                product_id INTEGER REFERENCES products(id) ON DELETE CASCADE,
                quantity INTEGER DEFAULT 1
            )
        `);
        console.log('✅ Таблица cart готова');

        // Проверяем количество товаров
        const result = await pool.query('SELECT COUNT(*) FROM products');
        const count = parseInt(result.rows[0].count);

        if (count === 0) {
            const products = [
                ['Фигурка Monkey D. Luffy (Gear 5)', 'figurine', 8900, 'Фигурка Луффи в форме Gear 5. Высота 25 см.', '/photo/luffyG5.png', 12],
                ['Фигурка Roronoa Zoro', 'figurine', 8500, 'Фигурка Зоро. Высота 24 см.', '/photo/zoro.png', 10],
                ['Фигурка Portgas D. Ace', 'figurine', 8900, 'Фигурка Эйса. Высота 25 см.', '/photo/ace.png', 8],
                ['Плюшевый Бепо', 'figurine', 2800, 'Мягкая игрушка Бепо 30 см', '/photo/chopper.png', 25],
                ['Плюшевый Чоппер', 'figurine', 2500, 'Мягкая игрушка Чоппера 25 см', '/photo/bepo.png', 30],
                ['Соломенная шляпа Луффи', 'clothing', 3500, 'Шляпа Луффи. Размер регулируется.', '/photo/mugiwara.png', 20],
                ['Шляпа Трафальгара Ло', 'clothing', 4200, 'Шляпа капитана Пиратов Сердца', '/photo/loup.png', 15],
                ['Джинсы Трафальгара Ло', 'clothing', 5500, 'Джинсы Ло', '/photo/lodown.png', 10],
                ['Серьги Зоро', 'accessory', 1800, 'Три золотые серьги Зоро', '/photo/zorogold.png', 40],
                ['Очки Дофламинго', 'accessory', 3200, 'Стильные очки Дофламинго', '/photo/mingo.png', 18],
                ['Ден-Ден Муши', 'accessory', 2400, 'Улитка для разговоров', '/photo/denden.png', 22],
                ['Катана Энма', 'accessory', 12500, 'Один из мечей Зоро', '/photo/enma.png', 5],
                ['Катана Вадо Ичимоджи', 'accessory', 12500, 'Один из мечей Зоро', '/photo/vado.png', 5],
                ['Дьявольский фрукт Эйса', 'accessory', 8900, 'Дьявольский фрукт Мера-Мера Но Ми', '/photo/meramera.png', 8],
                ['Постеры Мугивар', 'poster', 1200, 'Постер всех членов команды Соломенной Шляпы', '/photo/posters.png', 35],
                ['Постер Шанкса', 'poster', 1200, 'Постер Красноволосого', '/photo/akagami.png', 35],
                ['One Piece. Том 1', 'manga', 550, 'Первый том', '/photo/1T.png', 50],
                ['One Piece. Том 2', 'manga', 550, 'Второй том', '/photo/3T.png', 50],
                ['One Piece. Том 3', 'manga', 550, 'Третий том', '/photo/2T.png', 50]
            ];

            for (const p of products) {
                await pool.query(
                    'INSERT INTO products (name, category, price, description, image_url, stock) VALUES ($1, $2, $3, $4, $5, $6)',
                    p
                );
            }
            console.log('✅ Добавлены товары (19 шт.)');
        } else {
            console.log(`📦 Найдено ${count} товаров в базе`);
        }

        // Проверяем наличие буферной таблицы (для задания преподавателя)
        const bufferCheck = await pool.query(`
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name = 'buffer_data'
            )
        `);
        
        if (bufferCheck.rows[0].exists) {
            console.log('✅ Буферная таблица buffer_data найдена (динамическая БД работает!)');
        } else {
            console.log('⚠️ Буферная таблица не найдена. Создайте её через pgAdmin для задания преподавателя.');
        }

    } catch (err) {
        console.error('❌ Ошибка создания таблиц:', err.message);
    }
}

// Получить все товары (с фильтрацией)
app.get('/api/products', async (req, res) => {
    try {
        const { category, search } = req.query;
        let sql = 'SELECT * FROM products';
        let params = [];
        let conditions = [];
        let paramIndex = 1;

        if (category && category !== 'all') {
            conditions.push(`category = $${paramIndex}`);
            params.push(category);
            paramIndex++;
        }

        if (search) {
            conditions.push(`name ILIKE $${paramIndex}`);
            params.push(`%${search}%`);
            paramIndex++;
        }

        if (conditions.length > 0) {
            sql += ' WHERE ' + conditions.join(' AND ');
        }

        sql += ' ORDER BY created_at DESC';

        const result = await pool.query(sql, params);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Получить один товар
app.get('/api/products/:id', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM products WHERE id = $1', [req.params.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Товар не найден' });
        }
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Добавить товар
app.post('/api/products', async (req, res) => {
    try {
        const { name, category, price, description, image_url, stock } = req.body;

        if (!name || !category || !price) {
            return res.status(400).json({ error: 'Название, категория и цена обязательны' });
        }

        const result = await pool.query(
            'INSERT INTO products (name, category, price, description, image_url, stock) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [name, category, price, description || '', image_url || '', stock || 0]
        );
        res.json(result.rows[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Обновить товар
app.put('/api/products/:id', async (req, res) => {
    try {
        const { name, category, price, description, image_url, stock } = req.body;

        const result = await pool.query(
            'UPDATE products SET name=$1, category=$2, price=$3, description=$4, image_url=$5, stock=$6 WHERE id=$7 RETURNING *',
            [name, category, price, description || '', image_url || '', stock || 0, req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Товар не найден' });
        }
        res.json({ message: 'Товар обновлен' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Удалить товар
app.delete('/api/products/:id', async (req, res) => {
    try {
        const result = await pool.query('DELETE FROM products WHERE id = $1', [req.params.id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ error: 'Товар не найден' });
        }
        res.json({ message: 'Товар удален' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Регистрация
app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return res.status(400).json({ error: 'Все поля обязательны' });
        }

        const simpleHash = Buffer.from(password).toString('base64');

        const result = await pool.query(
            'INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING id, username, email',
            [username, email, simpleHash]
        );
        res.json({ message: 'Регистрация успешна', user: result.rows[0] });
    } catch (err) {
        if (err.message.includes('unique') || err.code === '23505') {
            return res.status(400).json({ error: 'Пользователь с таким email уже существует' });
        }
        res.status(500).json({ error: err.message });
    }
});

// Авторизация
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const simpleHash = Buffer.from(password).toString('base64');

        const result = await pool.query(
            'SELECT id, username, email FROM users WHERE email = $1 AND password = $2',
            [email, simpleHash]
        );

        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'Неверный email или пароль' });
        }
        res.json({ message: 'Вход выполнен', user: result.rows[0] });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ============= API ДЛЯ БУФЕРНОЙ ТАБЛИЦЫ (задание преподавателя) =============

// Добавляем данные через буфер (БД)
app.post('/api/buffer', async (req, res) => {
    try {
        const { object_name, properties } = req.body;

        if (!object_name || !properties) {
            return res.status(400).json({ error: 'object_name и properties обязательны' });
        }

        const result = await pool.query(
            'INSERT INTO buffer_data (object_name, properties) VALUES ($1, $2) RETURNING *',
            [object_name, JSON.stringify(properties)]
        );
        res.json({ 
            message: 'Данные добавлены в буфер. Триггер автоматически создал/обновил таблицу!',
            data: result.rows[0] 
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Получаем все созданные таблицы
app.get('/api/dynamic-tables', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            ORDER BY table_name
        `);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен на http://localhost:${PORT}`);
});