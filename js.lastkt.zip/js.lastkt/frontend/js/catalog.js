let currentProducts = [];

async function loadProducts() {
    try {
        const category = document.getElementById('categoryFilter')?.value || 'all';
        const search = document.getElementById('searchInput')?.value || '';
        let url = `${API_URL}/products?category=${category}`;
        if (search) url += `&search=${search}`;
        
        const response = await fetch(url);
        currentProducts = await response.json();
        renderProducts();
    } catch (error) {
        showNotification('Ошибка загрузки', 'error');
    }
}

function renderProducts() {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;
    
    grid.innerHTML = currentProducts.map(product => {

        let imageUrl = product.image_url || 'https://via.placeholder.com/300x400';
        if (imageUrl.startsWith('/photo/')) {
            imageUrl = imageUrl.substring(1); 
        }
        
        return `
            <div class="product-card">
                <img src="${imageUrl}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p class="price">${product.price} ₽</p>
                <p class="stock">В наличии: ${product.stock}</p>
                <div class="product-buttons">
                    <button onclick="editProduct(${product.id})" class="btn-secondary">✏️</button>
                    <button onclick="deleteProduct(${product.id})" class="btn-danger">🗑️</button>
                </div>
            </div>
        `;
    }).join('');
}

async function deleteProduct(id) {
    if (confirm('Удалить товар?')) {
        try {
            await fetch(`${API_URL}/products/${id}`, { method: 'DELETE' });
            showNotification('Товар удален');
            loadProducts();
        } catch (error) {
            showNotification('Ошибка удаления', 'error');
        }
    }
}

async function editProduct(id) {
    const product = currentProducts.find(p => p.id === id);
    if (!product) return;
    
    document.getElementById('modalTitle').textContent = 'Редактировать товар';
    document.getElementById('productId').value = product.id;
    document.getElementById('productName').value = product.name;
    document.getElementById('productCategory').value = product.category;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productDesc').value = product.description || '';
    document.getElementById('productImage').value = product.image_url || '';
    document.getElementById('productStock').value = product.stock;
    
    document.getElementById('productModal').style.display = 'block';
}

document.getElementById('productForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('productId').value;
    const product = {
        name: document.getElementById('productName').value,
        category: document.getElementById('productCategory').value,
        price: parseFloat(document.getElementById('productPrice').value),
        description: document.getElementById('productDesc').value,
        image_url: document.getElementById('productImage').value,
        stock: parseInt(document.getElementById('productStock').value) || 0
    };
    
    try {
        const url = id ? `${API_URL}/products/${id}` : `${API_URL}/products`;
        const method = id ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(product)
        });
        
        if (response.ok) {
            showNotification(id ? 'Товар обновлен' : 'Товар добавлен');
            document.getElementById('productModal').style.display = 'none';
            document.getElementById('productForm').reset();
            document.getElementById('productId').value = '';
            loadProducts();
        }
    } catch (error) {
        showNotification('Ошибка сохранения', 'error');
    }
});

document.getElementById('addProductBtn')?.addEventListener('click', () => {
    document.getElementById('modalTitle').textContent = 'Добавить товар';
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('productModal').style.display = 'block';
});

document.querySelector('.close')?.addEventListener('click', () => {
    document.getElementById('productModal').style.display = 'none';
});

document.getElementById('searchInput')?.addEventListener('input', loadProducts);
document.getElementById('categoryFilter')?.addEventListener('change', loadProducts);

if (document.getElementById('productsGrid')) {
    loadProducts();
}