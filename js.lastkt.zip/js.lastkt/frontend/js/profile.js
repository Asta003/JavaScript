document.getElementById('register')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        
        if (response.ok) {
            showNotification('Регистрация успешна!');
            document.getElementById('register').reset();
        } else {
            const error = await response.json();
            document.getElementById('regError').textContent = error.error;
        }
    } catch (error) {
        showNotification('Ошибка регистрации', 'error');
    }
});

document.getElementById('login')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('user', JSON.stringify(data.user));
            showNotification(`Добро пожаловать, ${data.user.username}!`);
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('registerForm').style.display = 'none';
            document.getElementById('profileInfo').style.display = 'block';
            document.getElementById('userName').textContent = data.user.username;
        } else {
            const error = await response.json();
            document.getElementById('loginError').textContent = error.error;
        }
    } catch (error) {
        showNotification('Ошибка входа', 'error');
    }
});

document.getElementById('logoutBtn')?.addEventListener('click', () => {
    localStorage.removeItem('user');
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('registerForm').style.display = 'block';
    document.getElementById('profileInfo').style.display = 'none';
    showNotification('Вы вышли из системы');
});

// Проверка авторизации при загрузке
const user = localStorage.getItem('user');
if (user && document.getElementById('profileInfo')) {
    const userData = JSON.parse(user);
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('profileInfo').style.display = 'block';
    document.getElementById('userName').textContent = userData.username;
}