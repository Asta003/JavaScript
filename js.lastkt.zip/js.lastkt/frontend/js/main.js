async function loadSliderProducts() {
    try {
        const response = await fetch(`${API_URL}/products`);
        const products = await response.json();
        const sliderProducts = products.slice(0, 5);
        
        const slider = document.getElementById('slider');
        if (slider) {
            slider.innerHTML = sliderProducts.map(product => {
                let imageUrl = product.image_url || 'https://via.placeholder.com/300x400';
                if (imageUrl.startsWith('/photo/')) {
                    imageUrl = imageUrl.substring(1); 
                }
                
                return `
                    <div class="slider-card">
                        <img src="${imageUrl}" alt="${product.name}">
                        <h3>${product.name}</h3>
                        <p class="price">${product.price} ₽</p>
                    </div>
                `;
            }).join('');
        }
        
        const sliderEl = document.getElementById('slider');
        const prevBtn = document.querySelector('.slider-btn.prev');
        const nextBtn = document.querySelector('.slider-btn.next');
        
        if (prevBtn && nextBtn) {
            prevBtn.onclick = () => sliderEl.scrollBy({ left: -300, behavior: 'smooth' });
            nextBtn.onclick = () => sliderEl.scrollBy({ left: 300, behavior: 'smooth' });
        }
    } catch (error) {
        console.error('Ошибка:', error);
    }
}

if (document.getElementById('slider')) {
    loadSliderProducts();
}